package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class DummyTests {
    ChromeDriver driver = null;

    @BeforeTest
    public void beforeTest(){
        //Initiating a chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\SQtest\\Downloads\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void getAllLinks() throws Exception{
        //open google.com
        driver.get("http://www.google.com");

        //verify global search button appears
        WebDriverWait wait=new WebDriverWait(driver, 20);
        WebElement searchButton1;
        searchButton1= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "(//*[@id='tsf']//div/center/input[@name='btnK'])[2]")));

        //enter the text in the search text field
        WebElement txtSearchField;
        txtSearchField = driver.findElement(By.xpath("//*[@id=\"tsf\"]//input[@name='q']"));
        txtSearchField.sendKeys("selenium");

        //hit search - search button of the autocomplete box is displayed
        WebElement searchButton2;
        searchButton2= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "(//*[@id='tsf']//div/center/input[@name='btnK'])[1]")));
        searchButton2.click();

        //print all the links
        List<WebElement> allLinks = driver.findElements(By.xpath("//*[@id=\"rcnt\"]//div[@class='r']/a"));
        for (int i = 0; i < allLinks.size(); i++) {
            System.out.println(allLinks.get(i).getAttribute("href"));
        }

    }  //end of test
    @Test
    public void openGITHubIssue() throws Exception{
        //open google.com
        driver.get("http://www.google.com");

        //verify global search button appears
        WebDriverWait wait=new WebDriverWait(driver, 20);
        WebElement searchButton1;
        searchButton1= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "(//*[@id='tsf']//div/center/input[@name='btnK'])[2]")));

        //enter the text in the search text field
        WebElement txtSearchField;
        txtSearchField = driver.findElement(By.xpath("//*[@id=\"tsf\"]//input[@name='q']"));
        //** Since I don't see the selenium git in the displayed results I add the letter g to the seach
        txtSearchField.sendKeys("selenium g");


        //get the text matching with seleniun github
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[role='option']")));
        List<WebElement> results = driver.findElements(By.cssSelector("[role='option']"));

        //get and enter the result matching selenium github
        WebElement we = null;


        for (int i = 0; i < results.size(); i++) {
            if (results.get(i).getText().equalsIgnoreCase("selenium github")){
                we = results.get(i);
                System.out.println("got the result");
                break;
            }
        }


        we.click();

        //validating the expected link is  the first search option
        String expectedLinkText = "https://github.com/SeleniumHQ/selenium";
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"rcnt\"]//div[@class='r']/a[1]")).getAttribute("href"),expectedLinkText);

        //clicking the first search result
        driver.findElement(By.xpath("//*[@id=\"rcnt\"]//div[@class='r']/a[1]")).click();

        //validating the repo is SelniumHQ/selenium
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[1]/div/div/h1/strong/a")));

        String expectedRepo = "https://github.com/SeleniumHQ/selenium";
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[1]/div/div/h1/strong/a"))
         .getAttribute("href"),expectedRepo);


        //click the "Clone or Download" button
        driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[5]/details[2]/summary")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"js-repo-pjax-container\"]//input[contains(@aria-label,'Clone')]")));

        //Print the Url
        System.out.println(driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]//input[contains(@aria-label,'Clone')]")).getAttribute("value"));
        driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[5]/details[2]/summary")).click();


        //Find Open issue with subject "Zooming browsers using short cut keys such as "CMD+" does not work"
        //get to Issues pane
        driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[1]/nav/span[2]/a")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("js-issues-search")));
        WebElement searchIssue = driver.findElement(By.id("js-issues-search"));

        searchIssue.sendKeys("Zooming browsers using short cut keys such as \"CMD+\" does not work");
        searchIssue.sendKeys(Keys.ENTER);

        //click on first comment
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"issue_7793\"]/div/div[3]/span[3]/a")));
        driver.findElement(By.xpath("//*[@id=\"issue_7793\"]/div/div[3]/span[3]/a")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@id,'issuecomment')]")));
        //print the date of the last comment
        WebElement lastComment = driver.findElement(By.xpath("//a[contains(@id,'issuecomment')][last()]/relative-time"));
        System.out.println("date of last comment is: " + lastComment.getAttribute("title"));










    }



    @AfterTest
    public void afterTest() {
        //quit the driver if you want - also teardown is possible in after class
       // driver.quit();
    }

}
